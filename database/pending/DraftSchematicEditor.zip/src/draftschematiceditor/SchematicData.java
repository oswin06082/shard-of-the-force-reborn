/**
 *
 * @author TaSwavo
 * 
*/

package draftschematiceditor;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.sql.DriverManager;

public class SchematicData {

    static String sDataTable  = "testschematic";
    int i;

    private int iNumOfSchematics;
    private int iMaxNumberIngredients = 11;
    private int iMaxNumberExp = 15;

    //vector of schematics
    Vector<Schematic> vSchematic;
    
    //public Hashtable hSchematic;
    
    //key for the hashtable
    int key;

    //schematic instance that can be used to get data and is used internally
    //during data retrieval methods
    Schematic tSchematic;
    
    private Connection conn;
   
    Statement s;  // should not be needed maybe when implemented properly
    

    public int getMaxNumberIngredients() { return( iMaxNumberIngredients); }
    public int getMaxNumberExp()          { return( iMaxNumberExp); }
    
    public SchematicData() {

// I put some stuff in here to connect to my MYSQL
// this is for testing only and will probably not be required depending
// upon where the code were used
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            String serverName = "localhost";
            String mydatabase = "tgcraft_swgprecu";
            String url = "jdbc:mysql://" + serverName + "/" + mydatabase;
            String username = "root";
            String password = "buggie";
            conn = DriverManager.getConnection(url, username, password);             
            s = conn.createStatement();
        }
        catch (SQLException e) {
            System.out.println("SQL Exception encountered." + e.toString());
            System.out.println("Message: " + e.getMessage());
            System.out.println("SQLState: " + e.getSQLState());
            System.out.println("VendorError: " + e.getErrorCode());
            e.printStackTrace();
        }
        catch (Exception e) {
            System.out.println("Error:  Could not create statement!  Error: " + e.toString());
            e.printStackTrace();
            System.exit(-1);
	}
        
// the above section could probably be removed if s is set elsewhere

        getSchematicCount();
        LoadSchematics();
        
    }

    
    private void setNumOfSchematics(int i) {
        iNumOfSchematics = i;
    }
    public int getNumOfSchematics() {
        return iNumOfSchematics;
    }
    public void getSchematicCount() {
        int iRetVal = 0;
        
        try {
            String query = "SELECT count(*) from `schematic`;";
            if (s.execute(query)) {
                ResultSet result = s.getResultSet();
                result.next();
                iRetVal = result.getInt(1);
                setNumOfSchematics( iRetVal );
            }
        }
        catch (Exception e) {
            System.out.println("Error:  Could not get schematic count!  Error: " + e.toString());
            e.printStackTrace();
            System.exit(-1);
	}
        
    }

    private int LoadSchematics() {
        int iNum = 0;

        try {
            String query = "SELECT * from `" + sDataTable + "`;";
            if (s.execute(query)) {
                ResultSet result = s.getResultSet();

                // this should set the vector to be the right size
                // so it should not need to increase
                // increment set to 1 (otherwise it doubles if it has to grow)
                vSchematic = new Vector<Schematic>(getNumOfSchematics(),1);
                //hSchematic = new Hashtable(getNumOfSchematics());
                
                while (result.next()) {
//                    Schematic NewData = new Schematic();
                    Schematic NewData;
                    NewData = PopulateNewData(result);
                    vSchematic.add(NewData);
                    
                    //hSchematic.put(key, NewData);
                    
                            
                    
                    iNum++;
                }
            }
        }
        catch (Exception e) {
            System.out.println("Error loading schematic list." + e.toString());
            e.printStackTrace();
        }

        // could check here that i = iNumOfSchematics ?
        setNumOfSchematics(iNum);

        return iNum;
    }
    
    private Schematic PopulateNewData(ResultSet result) {
        Schematic NewData = new Schematic();
        
        int iResultPosition = 1;
        int iSectionLoop;
        
        try {
            //NewData.iSchematicCRC = result.getInt(1);  now used as key
            //key = result.getInt(2); // should be 1, not 2
            NewData.iSchematicCRC = result.getInt(1);
            NewData.iSchematicID  = result.getInt(2);
            NewData.sSchematic    = result.getString(3);
            NewData.sSkillID      = result.getString(4);
            NewData.sXPPoints     = result.getString(5);
            NewData.sXPType       = result.getString(6);
            NewData.sComplexity   = result.getString(7);
            NewData.sDatasize     = result.getString(8);
            NewData.sIFFfilename  = result.getString(9);
            NewData.iMaybe        = result.getInt(10);
            iResultPosition += 10;

            for( iSectionLoop=0; iSectionLoop<iMaxNumberIngredients; iSectionLoop++ )
            {
                NewData.sSTFfilename[iSectionLoop]    = result.getString(iResultPosition+0);
                NewData.sSTFkey[iSectionLoop]         = result.getString(iResultPosition+1);
                NewData.sSTFvalue[iSectionLoop]       = result.getString(iResultPosition+2);
                NewData.sNeeded[iSectionLoop]         = result.getString(iResultPosition+3);
                NewData.sResComp[iSectionLoop]        = result.getString(iResultPosition+4);
                NewData.sIdentical[iSectionLoop]      = result.getString(iResultPosition+5);
                NewData.sQuantity[iSectionLoop]       = result.getString(iResultPosition+6);
                NewData.sOptional[iSectionLoop]       = result.getString(iResultPosition+7);
                NewData.sSTFneeded[iSectionLoop]      = result.getString(iResultPosition+8);
                iResultPosition += 9;
//                if( !NewData.sResourceName[iSectionLoop].isEmpty() )
//                    NewData.iNumberResources++;
            }
            for( iSectionLoop=0; iSectionLoop<iMaxNumberExp; iSectionLoop++ )
            {
                NewData.sExpMain[iSectionLoop] = result.getString(iResultPosition+0);
                NewData.sExpDesc[iSectionLoop] = result.getString(iResultPosition+1);
                NewData.iExpER[iSectionLoop]   = result.getInt(iResultPosition+2);
                NewData.iExpCR[iSectionLoop]   = result.getInt(iResultPosition+3);
                NewData.iExpCD[iSectionLoop]   = result.getInt(iResultPosition+4);
                NewData.iExpDR[iSectionLoop]   = result.getInt(iResultPosition+5);
                NewData.iExpFL[iSectionLoop]   = result.getInt(iResultPosition+6);
                NewData.iExpHR[iSectionLoop]   = result.getInt(iResultPosition+7);
                NewData.iExpMA[iSectionLoop]   = result.getInt(iResultPosition+8);
                NewData.iExpPE[iSectionLoop]   = result.getInt(iResultPosition+9);
                NewData.iExpOQ[iSectionLoop]   = result.getInt(iResultPosition+10);
                NewData.iExpSR[iSectionLoop]   = result.getInt(iResultPosition+11);
                NewData.iExpUT[iSectionLoop]   = result.getInt(iResultPosition+12);
                NewData.iSlot[iSectionLoop]    = result.getInt(iResultPosition+13);
                iResultPosition += 14;
            }

            NewData.sIFFCraftedItem = result.getString(iResultPosition);
            iResultPosition++;
            
            NewData.setNumberIngredients();
            NewData.setNumberExp();
        }
        catch (Exception e) {
           System.out.println("Error filling Schematic   Error: " + e.toString());
           e.printStackTrace();
           System.exit(-1);
        }
        return NewData;
    }
    
    public class Schematic {
        private int iNumberIngredients;
        private int iNumberExp;
        
        private int iSchematicCRC;
    	private int iSchematicID;
        private String sSchematic;
    	private String sSkillID;
        private String sXPPoints;
    	private String sXPType;
        private String sComplexity;
    	private String sDatasize;

        private String sIFFfilename;
        private int iMaybe;
        
        private String sSTFfilename[] = new String[iMaxNumberIngredients];
        private String sSTFkey[] = new String[iMaxNumberIngredients];
        private String sSTFvalue[] = new String[iMaxNumberIngredients];
        private String sNeeded[] = new String[iMaxNumberIngredients];
        private String sResComp[] = new String[iMaxNumberIngredients];
        private String sIdentical[] = new String[iMaxNumberIngredients];
        private String sQuantity[] = new String[iMaxNumberIngredients];
        private String sOptional[] = new String[iMaxNumberIngredients];
        private String sSTFneeded[] = new String[iMaxNumberIngredients];

       
        private String sExpMain[] = new String[iMaxNumberExp];
        private String sExpDesc[] = new String[iMaxNumberExp];
        private int iExpER[] = new int[iMaxNumberExp];
        private int iExpCR[] = new int[iMaxNumberExp];
        private int iExpCD[] = new int[iMaxNumberExp];
        private int iExpDR[] = new int[iMaxNumberExp];
        private int iExpFL[] = new int[iMaxNumberExp];
        private int iExpHR[] = new int[iMaxNumberExp];
        private int iExpMA[] = new int[iMaxNumberExp];
        private int iExpPE[] = new int[iMaxNumberExp];
        private int iExpOQ[] = new int[iMaxNumberExp];
        private int iExpSR[] = new int[iMaxNumberExp];
        private int iExpUT[] = new int[iMaxNumberExp];
        private int iSlot[] = new int[iMaxNumberExp];

        private String sIFFCraftedItem;

        private void setNumberIngredients() {
            for( int iSectionLoop=0; iSectionLoop<iMaxNumberIngredients; iSectionLoop++ )
            {
                if( sNeeded[iSectionLoop].isEmpty() ) {
                    iNumberIngredients = iSectionLoop;
                    return;
                }
            }
        }
        private void setNumberExp() {
            for( int iSectionLoop=0; iSectionLoop<iMaxNumberExp; iSectionLoop++ )
            {
                if( sExpMain[iSectionLoop].isEmpty() ) {
                    iNumberExp = iSectionLoop;
                    return;
                }
            }
        }
        
        int getNumberIngredients(){ return iNumberIngredients; }
        int getNumberExp()        { return iNumberExp; }
        
        int getSchematicCRC()  { return iSchematicCRC; }
        int getSchematicID()   { return iSchematicID; }
        String getSchematic()  { return sSchematic; }
        String getSkillID()    { return sSkillID; }
        String getXPPoints()   { return sXPPoints; }
        String getXPType()     { return sXPType; }
        String getComplexity() { return sComplexity; }
        String getDatasize()   { return sDatasize; }
        String getIFFfilename(){ return sIFFfilename; }
        int getMaybe()         { return iMaybe; }
        
        String getSTFfilename(int index)  { return  sSTFfilename[index]; }
        String getSTFkey(int index)       { return  sSTFkey[index]; }
        String getSTFvalue(int index)     { return  sSTFvalue[index]; }
        String getNeeded(int index)       { return  sNeeded[index]; }
        String getResComp(int index)      { return  sResComp[index]; }
        String getIdentical(int index)    { return  sIdentical[index]; }
        String getQuantity(int index)     { return  sQuantity[index]; }
        String getOptional(int index)     { return  sOptional[index]; }
        String getSTFneeded(int index)    { return  sSTFneeded[index]; }
        
        String getExpMain(int index) { return sExpMain[index]; }
        String getExpDesc(int index) { return sExpDesc[index]; }
        int getExpER(int index)      { return iExpER[index]; }
        int getExpCR(int index)      { return iExpCR[index]; }
        int getExpCD(int index)      { return iExpCD[index]; }
        int getExpDR(int index)      { return iExpDR[index]; }
        int getExpFL(int index)      { return iExpFL[index]; }
        int getExpHR(int index)      { return iExpHR[index]; }
        int getExpMA(int index)      { return iExpMA[index]; }
        int getExpPE(int index)      { return iExpPE[index]; }
        int getExpOQ(int index)      { return iExpOQ[index]; }
        int getExpSR(int index)      { return iExpSR[index]; }
        int getExpUT(int index)      { return iExpUT[index]; }
        int getSlot(int index)       { return iSlot[index]; }

        String getIFFCreatedItem()   { return sIFFCraftedItem; }
        
    }
    
    public int getSchematicIDByName( String SName ) {
        for( int index=0; index<iNumOfSchematics; index++ )
        {
            tSchematic = vSchematic.get(index);
            if( tSchematic.getSchematic().equalsIgnoreCase(SName) )
                return index;
        }
        return -1;
    }
            
    public Schematic getSchematicByName( String SName ) {
        Schematic locSchematic = new Schematic();
        for( int index=0; index<iNumOfSchematics; index++ )
        {
            locSchematic = vSchematic.get(index);
            
            if( locSchematic.getSchematic().equalsIgnoreCase(SName) )
                return locSchematic;
        }
        return null;
    }
            
    public Schematic getSchematicByID( int index ) {
        return vSchematic.get(index);
    }

    private String getSlash(Boolean bStarted) {
        if(bStarted) { return " / "; }
        else         { return ""; }
    }

    
    // not sure if this will be wanted but it's handy for testing    
    public String getExpString(Schematic sc, int index) {
        String sReturn = "";
        Boolean bStarted = false; 
        
        if( sc.getExpER(index)>0 ) { 
            if(bStarted) { sReturn += " / "; }
            sReturn += "ER "+sc.iExpER[index];
            bStarted = true;
        }
        if( sc.getExpCR(index)>0 ) { 
            if(bStarted) { sReturn += " / "; }
            sReturn += "CR "+sc.iExpCR[index];
            bStarted = true;
        }
        if( sc.getExpCD(index)>0 ) { 
            if(bStarted) { sReturn += " / "; }
            sReturn += "CD "+sc.iExpCD[index];
            bStarted = true;
        }
        if( sc.getExpDR(index)>0 ) { 
            if(bStarted) { sReturn += " / "; }
            sReturn += "DR "+sc.iExpDR[index];
            bStarted = true;
        }
        if( sc.getExpFL(index)>0 ) { 
            if(bStarted) { sReturn += " / "; }
            sReturn += "FL "+sc.iExpFL[index];
            bStarted = true;
        }
        if( sc.getExpHR(index)>0 ) { 
            if(bStarted) { sReturn += " / "; }
            sReturn += "HR "+sc.iExpHR[index];
            bStarted = true;
        }
        if( sc.getExpMA(index)>0 ) { 
            if(bStarted) { sReturn += " / "; }
            sReturn += "MA "+sc.iExpMA[index];
            bStarted = true;
        }
        if( sc.getExpPE(index)>0 ) { 
            if(bStarted) { sReturn += " / "; }
            sReturn += "PE "+sc.iExpPE[index];
            bStarted = true;
        }
        if( sc.getExpOQ(index)>0 ) { 
            if(bStarted) { sReturn += " / "; }
            sReturn += "OQ "+sc.iExpOQ[index];
            bStarted = true;
        }
        if( sc.getExpSR(index)>0 ) { 
            if(bStarted) { sReturn += " / "; }
            sReturn += "SR "+sc.iExpSR[index];
            bStarted = true;
        }
        if( sc.getExpUT(index)>0 ) { 
            if(bStarted) { sReturn += " / "; }
            sReturn += "UT "+sc.iExpUT[index];
            bStarted = true;
        }
            
        return sReturn;
    }
            
}  //end public class SchematicData

