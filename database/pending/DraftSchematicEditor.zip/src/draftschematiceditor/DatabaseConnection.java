package draftschematiceditor;

/**
 *
 * @author Dave
 */


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.Hashtable;
import java.sql.DriverManager;


public class DatabaseConnection {

    private Connection conn;
   
    Statement s;
    
    public DatabaseConnection() {
        
        //
        // Establish connection to database
        //
        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            String serverName = "localhost";
            String mydatabase = "tgcraft_swgprecu";
            String url = "jdbc:mysql://" + serverName + "/" + mydatabase;
            String username = "root";
            String password = "buggie";
            conn = DriverManager.getConnection(url, username, password);             
            s = conn.createStatement();
        }
        catch (SQLException e) {
            System.out.println("SQL Exception encountered." + e.toString());
            System.out.println("Message: " + e.getMessage());
            System.out.println("SQLState: " + e.getSQLState());
            System.out.println("VendorError: " + e.getErrorCode());
            e.printStackTrace();
        }
        catch (Exception e) {
            System.out.println("Error:  Could not create statement!  Error: " + e.toString());
            e.printStackTrace();
            System.exit(-1);
        }
    }
    
    public ResultSet Query( String q ) {

        ResultSet result = null;

        try {
            if (s.execute(q)) {
                result = s.getResultSet();
            }
        }
        catch (SQLException e) {
            System.out.println("SQL Exception encountered." + e.toString());
            System.out.println("Message: " + e.getMessage());
            System.out.println("SQLState: " + e.getSQLState());
            System.out.println("VendorError: " + e.getErrorCode());
            e.printStackTrace();
        }
        catch (Exception e) {
            System.out.println("Error:  Could not create statement!  Error: " + e.toString());
            e.printStackTrace();
            System.exit(-1);
        }
        
        return(result);
    }

    
    
    
    

}
