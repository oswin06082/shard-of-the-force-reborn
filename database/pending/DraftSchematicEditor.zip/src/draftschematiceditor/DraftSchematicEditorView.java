/*
 * DraftSchematicEditorView.java
 * 
 * this Swing application edits and updates the table stated in line 46
 * 
 * it requires the following tables in the same database
 *
 *      decoded_iff
 *      decoded_stf
 *      newsc2 - derived from maach's iffreader
 *      skills
 *      xp
 *
 */

package draftschematiceditor;

import org.jdesktop.application.Action;
import org.jdesktop.application.ResourceMap;
import org.jdesktop.application.SingleFrameApplication;
import org.jdesktop.application.FrameView;
import org.jdesktop.application.TaskMonitor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.JDialog;

import java.sql.ResultSet;

import java.util.Hashtable;
import java.util.Vector;


/**
 * The application's main frame.
 */
public class DraftSchematicEditorView extends FrameView {

    static int IngredientColumns = 9;
    static int IngredientRows = 11;
    static int ExperimentationColumns = 14;
    static int ExperimentationRows = 15;

    static int newSCfields = 120;

    static String sDataTable = "newschematic";

    SchematicData mTest;
    SchematicData.Schematic mySchematic;

    String IngredientArray[][] = new String[IngredientRows][IngredientColumns];
    String ExperimentationArray[][] = new String[ExperimentationRows][ExperimentationColumns];

    String newSC[] = new String[newSCfields];
    
    Hashtable MaybeLookup = new Hashtable();
    Hashtable XPTypeLookup = new Hashtable();
    Hashtable SkillGroupLookup = new Hashtable();

    Vector IFFList = new Vector();
    Vector TangibleListIFF = new Vector();
    Vector UnusedTangibleListIFF = new Vector();
    Vector UnusedTangibleListName = new Vector();
    Vector vXPTypeList = new Vector();
    Vector vSkillGroupList = new Vector();
    Vector vSchematicList = new Vector();
    Vector vMaybeList = new Vector();
    Vector vVariablesChanged = new Vector();

    int MaybeListValues[];
    String MaybeListStrings[];

    int iResListUsed = 0;
    int iExpListUsed = 0;





    public DraftSchematicEditorView(SingleFrameApplication app) {
        super(app);

        initComponents();

        // status bar initialization - message timeout, idle icon and busy animation, etc
        ResourceMap resourceMap = getResourceMap();
        int messageTimeout = resourceMap.getInteger("StatusBar.messageTimeout");
        messageTimer = new Timer(messageTimeout, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                statusMessageLabel.setText("");
            }
        });
        messageTimer.setRepeats(false);
        int busyAnimationRate = resourceMap.getInteger("StatusBar.busyAnimationRate");
        for (int i = 0; i < busyIcons.length; i++) {
            busyIcons[i] = resourceMap.getIcon("StatusBar.busyIcons[" + i + "]");
        }
        busyIconTimer = new Timer(busyAnimationRate, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                busyIconIndex = (busyIconIndex + 1) % busyIcons.length;
                statusAnimationLabel.setIcon(busyIcons[busyIconIndex]);
            }
        });
        idleIcon = resourceMap.getIcon("StatusBar.idleIcon");
        statusAnimationLabel.setIcon(idleIcon);
        progressBar.setVisible(false);

        // connecting action tasks to status bar via TaskMonitor
        TaskMonitor taskMonitor = new TaskMonitor(getApplication().getContext());
        taskMonitor.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                String propertyName = evt.getPropertyName();
                if ("started".equals(propertyName)) {
                    if (!busyIconTimer.isRunning()) {
                        statusAnimationLabel.setIcon(busyIcons[0]);
                        busyIconIndex = 0;
                        busyIconTimer.start();
                    }
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(true);
                } else if ("done".equals(propertyName)) {
                    busyIconTimer.stop();
                    statusAnimationLabel.setIcon(idleIcon);
                    progressBar.setVisible(false);
                    progressBar.setValue(0);
                } else if ("message".equals(propertyName)) {
                    String text = (String)(evt.getNewValue());
                    statusMessageLabel.setText((text == null) ? "" : text);
                    messageTimer.restart();
                } else if ("progress".equals(propertyName)) {
                    int value = (Integer)(evt.getNewValue());
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(false);
                    progressBar.setValue(value);
                }
            }
        });

        initSchematics();

        setUpRecordSpinner();

    }

    public void initSchematics() {

        mTest = new SchematicData();  // this loads the data from the database

        System.out.printf( mTest.getNumOfSchematics() + " schematics loaded");
        System.out.println();

        fillMaybeLookupHashTable();
        fillXPTypeLookupHashTable();
        fillSkillGroupLookupHashTable();

        fillIFFList();
        fillTangibleList();

        fillMaybeList();
        
        populateForm();
    }

    @Action
    public void showAboutBox() {
        if (aboutBox == null) {
            JFrame mainFrame = DraftSchematicEditorApp.getApplication().getMainFrame();
            aboutBox = new DraftSchematicEditorAboutBox(mainFrame);
            aboutBox.setLocationRelativeTo(mainFrame);
        }
        DraftSchematicEditorApp.getApplication().show(aboutBox);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        SchematicNameTextField = new javax.swing.JTextField();
        SkillGroupTextField = new javax.swing.JTextField();
        ComplexityTextField = new javax.swing.JTextField();
        DatasizeTextField = new javax.swing.JTextField();
        XPTextField = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        XPTypeTextField = new javax.swing.JTextField();
        maybeTextField = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        maybeAsNum = new javax.swing.JTextField();
        XPTypeAsNum = new javax.swing.JTextField();
        SkillGroupAsNum = new javax.swing.JTextField();
        RecordSpinner = new javax.swing.JSpinner();
        IFFSchematicTextField = new javax.swing.JTextField();
        IFFCreatedTextField = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        TabbedPane = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane = new javax.swing.JScrollPane();
        IngredientsTable = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        ExperimentationTable = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        VariablesTable = new javax.swing.JScrollPane();
        XPTypeList = new javax.swing.JList();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        SkillGroupList = new javax.swing.JList();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        UnusedSchematicsList = new javax.swing.JList();
        AddBlankSchematicButton = new javax.swing.JButton();
        AddSchematicButton = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        MaybeList = new javax.swing.JList();
        jScrollPane2 = new javax.swing.JScrollPane();
        DraftSchematicList = new javax.swing.JList();
        jScrollPane3 = new javax.swing.JScrollPane();
        CreatedItemList = new javax.swing.JList();
        SubmitChangeButton = new javax.swing.JButton();
        SearchButton = new javax.swing.JButton();
        RestoreButton = new javax.swing.JButton();
        menuBar = new javax.swing.JMenuBar();
        javax.swing.JMenu fileMenu = new javax.swing.JMenu();
        javax.swing.JMenuItem exitMenuItem = new javax.swing.JMenuItem();
        javax.swing.JMenu helpMenu = new javax.swing.JMenu();
        javax.swing.JMenuItem aboutMenuItem = new javax.swing.JMenuItem();
        statusPanel = new javax.swing.JPanel();
        javax.swing.JSeparator statusPanelSeparator = new javax.swing.JSeparator();
        statusMessageLabel = new javax.swing.JLabel();
        statusAnimationLabel = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();

        mainPanel.setName("mainPanel"); // NOI18N

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("General"));
        jPanel3.setName("jPanel3"); // NOI18N

        SchematicNameTextField.setName("SchematicNameTextField"); // NOI18N

        SkillGroupTextField.setName("SkillGroupTextField"); // NOI18N
        SkillGroupTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                FocusGainedSkillGroup(evt);
            }
        });

        ComplexityTextField.setName("ComplexityTextField"); // NOI18N

        DatasizeTextField.setName("DatasizeTextField"); // NOI18N

        XPTextField.setName("XPTextField"); // NOI18N

        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(draftschematiceditor.DraftSchematicEditorApp.class).getContext().getResourceMap(DraftSchematicEditorView.class);
        jLabel1.setText(resourceMap.getString("jLabel1.text")); // NOI18N
        jLabel1.setName("jLabel1"); // NOI18N

        jLabel2.setText(resourceMap.getString("jLabel2.text")); // NOI18N
        jLabel2.setName("jLabel2"); // NOI18N

        jLabel3.setText(resourceMap.getString("jLabel3.text")); // NOI18N
        jLabel3.setName("jLabel3"); // NOI18N

        jLabel4.setText(resourceMap.getString("jLabel4.text")); // NOI18N
        jLabel4.setName("jLabel4"); // NOI18N

        jLabel5.setText(resourceMap.getString("jLabel5.text")); // NOI18N
        jLabel5.setName("jLabel5"); // NOI18N

        jLabel6.setText(resourceMap.getString("jLabel6.text")); // NOI18N
        jLabel6.setName("jLabel6"); // NOI18N

        XPTypeTextField.setName("XPTypeTextField"); // NOI18N
        XPTypeTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                XPTypeFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                XPTypeFocusLost(evt);
            }
        });

        maybeTextField.setEditable(false);
        maybeTextField.setName("maybeTextField"); // NOI18N

        jLabel13.setText(resourceMap.getString("jLabel13.text")); // NOI18N
        jLabel13.setName("jLabel13"); // NOI18N

        maybeAsNum.setName("maybeAsNum"); // NOI18N
        maybeAsNum.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                MaybeAsNumGainedFocus(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                MaybeLostFocus(evt);
            }
        });

        XPTypeAsNum.setEditable(false);
        XPTypeAsNum.setName("XPTypeAsNum"); // NOI18N

        SkillGroupAsNum.setEditable(false);
        SkillGroupAsNum.setName("SkillGroupAsNum"); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(XPTextField)
                                .addComponent(ComplexityTextField)
                                .addComponent(DatasizeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(maybeTextField, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(XPTypeTextField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
                                .addComponent(SkillGroupTextField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(21, 21, 21)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(XPTypeAsNum, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                            .addComponent(SkillGroupAsNum, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                            .addComponent(maybeAsNum, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE))
                        .addGap(30, 30, 30))
                    .addComponent(SchematicNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 367, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SchematicNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SkillGroupTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(SkillGroupAsNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ComplexityTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DatasizeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(XPTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(XPTypeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(XPTypeAsNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, 0, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(maybeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(maybeAsNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        RecordSpinner.setModel(new javax.swing.SpinnerNumberModel(1, 1, 2215, 1));
        RecordSpinner.setName("RecordSpinner"); // NOI18N
        RecordSpinner.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                SpinnerStateChange(evt);
            }
        });

        IFFSchematicTextField.setName("IFFSchematicTextField"); // NOI18N

        IFFCreatedTextField.setName("IFFCreatedTextField"); // NOI18N

        jLabel14.setName("jLabel14"); // NOI18N

        jLabel15.setName("jLabel15"); // NOI18N

        TabbedPane.setName("TabbedPane"); // NOI18N

        jPanel5.setName("jPanel5"); // NOI18N

        jScrollPane.setName("jScrollPane"); // NOI18N

        IngredientsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STFfilename", "STFkey", "STFvalue", "Needed", "ResComp", "Identical", "Quantity", "Optional", "STFneeded"
            }
        ));
        IngredientsTable.setName("IngredientsTable"); // NOI18N
        jScrollPane.setViewportView(IngredientsTable);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 1083, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(95, Short.MAX_VALUE))
        );

        TabbedPane.addTab(resourceMap.getString("jPanel5.TabConstraints.tabTitle"), jPanel5); // NOI18N

        jPanel6.setName("jPanel6"); // NOI18N

        jScrollPane1.setName("jScrollPane1"); // NOI18N

        ExperimentationTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "STFheading", "STFtitle", "ER", "CR", "CD", "DR", "FL", "HR", "MA", "PE", "OQ", "SR", "UT", "Slot"
            }
        ));
        ExperimentationTable.setName("ExperimentationTable"); // NOI18N
        jScrollPane1.setViewportView(ExperimentationTable);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1083, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        TabbedPane.addTab(resourceMap.getString("jPanel6.TabConstraints.tabTitle"), jPanel6); // NOI18N

        jPanel1.setName("jPanel1"); // NOI18N

        VariablesTable.setName("VariablesTable"); // NOI18N

        XPTypeList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        XPTypeList.setName("XPTypeList"); // NOI18N
        XPTypeList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DClickXPTypeList(evt);
            }
        });
        VariablesTable.setViewportView(XPTypeList);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(VariablesTable, javax.swing.GroupLayout.PREFERRED_SIZE, 394, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(699, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(VariablesTable, javax.swing.GroupLayout.DEFAULT_SIZE, 272, Short.MAX_VALUE)
                .addContainerGap())
        );

        TabbedPane.addTab("XP Types", jPanel1);

        jPanel2.setName("jPanel2"); // NOI18N

        jScrollPane4.setName("jScrollPane4"); // NOI18N

        SkillGroupList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        SkillGroupList.setName("SkillGroupList"); // NOI18N
        SkillGroupList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DclickSkillGroupList(evt);
            }
        });
        jScrollPane4.setViewportView(SkillGroupList);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 394, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(699, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 272, Short.MAX_VALUE)
                .addContainerGap())
        );

        TabbedPane.addTab("Skill Groups", jPanel2);

        jPanel4.setName("jPanel4"); // NOI18N

        jScrollPane5.setName("jScrollPane5"); // NOI18N

        UnusedSchematicsList.setName("UnusedSchematicsList"); // NOI18N
        jScrollPane5.setViewportView(UnusedSchematicsList);

        AddBlankSchematicButton.setText(resourceMap.getString("AddBlankSchematicButton.text")); // NOI18N
        AddBlankSchematicButton.setName("AddBlankSchematicButton"); // NOI18N
        AddBlankSchematicButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddBlankSchematic(evt);
            }
        });

        AddSchematicButton.setText(resourceMap.getString("AddSchematicButton.text")); // NOI18N
        AddSchematicButton.setName("AddSchematicButton"); // NOI18N
        AddSchematicButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AddSelectedSchematic(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 522, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(AddSchematicButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AddBlankSchematicButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(407, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 272, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(AddSchematicButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 170, Short.MAX_VALUE)
                        .addComponent(AddBlankSchematicButton)))
                .addContainerGap())
        );

        TabbedPane.addTab(resourceMap.getString("jPanel4.TabConstraints.tabTitle"), jPanel4); // NOI18N

        jPanel7.setName("jPanel7"); // NOI18N

        jScrollPane6.setName("jScrollPane6"); // NOI18N

        MaybeList.setName("MaybeList"); // NOI18N
        MaybeList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DClickMaybeList(evt);
            }
        });
        jScrollPane6.setViewportView(MaybeList);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 395, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(698, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 272, Short.MAX_VALUE)
                .addContainerGap())
        );

        TabbedPane.addTab("Maybe List", jPanel7);

        jScrollPane2.setBorder(javax.swing.BorderFactory.createTitledBorder("Draft Schematic"));
        jScrollPane2.setName("jScrollPane2"); // NOI18N

        DraftSchematicList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        DraftSchematicList.setName("DraftSchematicList"); // NOI18N
        DraftSchematicList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DClickDraftSchematicsList(evt);
            }
        });
        jScrollPane2.setViewportView(DraftSchematicList);

        jScrollPane3.setBorder(javax.swing.BorderFactory.createTitledBorder("Created Item"));
        jScrollPane3.setName("jScrollPane3"); // NOI18N

        CreatedItemList.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        CreatedItemList.setName("CreatedItemList"); // NOI18N
        CreatedItemList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                DClickCreatedItemList(evt);
            }
        });
        jScrollPane3.setViewportView(CreatedItemList);

        SubmitChangeButton.setText(resourceMap.getString("SubmitChangeButton.text")); // NOI18N
        SubmitChangeButton.setName("SubmitChangeButton"); // NOI18N
        SubmitChangeButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ClickCommitButton(evt);
            }
        });

        SearchButton.setText(resourceMap.getString("SearchButton.text")); // NOI18N
        SearchButton.setName("SearchButton"); // NOI18N

        RestoreButton.setText(resourceMap.getString("RestoreButton.text")); // NOI18N
        RestoreButton.setName("RestoreButton"); // NOI18N
        RestoreButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clickRestoreButton(evt);
            }
        });

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(mainPanelLayout.createSequentialGroup()
                                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(RecordSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel15))
                                        .addGap(15, 15, 15))
                                    .addComponent(jLabel14))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(IFFCreatedTextField)
                                        .addComponent(IFFSchematicTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 485, Short.MAX_VALUE))
                                    .addComponent(SearchButton)))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addGap(152, 152, 152)
                                .addComponent(RestoreButton, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(31, 31, 31)
                                .addComponent(SubmitChangeButton)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 525, Short.MAX_VALUE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 525, Short.MAX_VALUE)))
                    .addComponent(TabbedPane, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1108, Short.MAX_VALUE))
                .addContainerGap())
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 228, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(IFFSchematicTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addGap(24, 24, 24)
                                .addComponent(RecordSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(mainPanelLayout.createSequentialGroup()
                                .addComponent(IFFCreatedTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(SearchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(29, 29, 29)
                        .addGroup(mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(SubmitChangeButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(RestoreButton, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)))
                    .addGroup(mainPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(31, 31, 31)
                .addComponent(TabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 322, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );

        TabbedPane.getAccessibleContext().setAccessibleName("tab4");

        menuBar.setName("menuBar"); // NOI18N

        fileMenu.setText(resourceMap.getString("fileMenu.text")); // NOI18N
        fileMenu.setName("fileMenu"); // NOI18N

        javax.swing.ActionMap actionMap = org.jdesktop.application.Application.getInstance(draftschematiceditor.DraftSchematicEditorApp.class).getContext().getActionMap(DraftSchematicEditorView.class, this);
        exitMenuItem.setAction(actionMap.get("quit")); // NOI18N
        exitMenuItem.setName("exitMenuItem"); // NOI18N
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        helpMenu.setAction(actionMap.get("showAboutBox")); // NOI18N
        helpMenu.setText(resourceMap.getString("helpMenu.text")); // NOI18N
        helpMenu.setName("helpMenu"); // NOI18N

        aboutMenuItem.setAction(actionMap.get("showAboutBox")); // NOI18N
        aboutMenuItem.setName("aboutMenuItem"); // NOI18N
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        statusPanel.setName("statusPanel"); // NOI18N

        statusPanelSeparator.setName("statusPanelSeparator"); // NOI18N

        statusMessageLabel.setName("statusMessageLabel"); // NOI18N

        statusAnimationLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        statusAnimationLabel.setName("statusAnimationLabel"); // NOI18N

        progressBar.setName("progressBar"); // NOI18N

        javax.swing.GroupLayout statusPanelLayout = new javax.swing.GroupLayout(statusPanel);
        statusPanel.setLayout(statusPanelLayout);
        statusPanelLayout.setHorizontalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(statusPanelSeparator, javax.swing.GroupLayout.DEFAULT_SIZE, 1128, Short.MAX_VALUE)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(statusMessageLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 958, Short.MAX_VALUE)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(statusAnimationLabel)
                .addContainerGap())
        );
        statusPanelLayout.setVerticalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addComponent(statusPanelSeparator, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(statusMessageLabel)
                    .addComponent(statusAnimationLabel)
                    .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3))
        );

        setComponent(mainPanel);
        setMenuBar(menuBar);
        setStatusBar(statusPanel);
    }// </editor-fold>//GEN-END:initComponents

    private void SpinnerStateChange(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_SpinnerStateChange
        clearForm();
        populateForm();
    }//GEN-LAST:event_SpinnerStateChange

    private void DClickCreatedItemList(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DClickCreatedItemList
        if( evt.getClickCount()==2 ) {
            IFFCreatedTextField.setText( CreatedItemList.getSelectedValue().toString() );
        }
    }//GEN-LAST:event_DClickCreatedItemList

    private void ClickCommitButton(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ClickCommitButton
        int loop;
        int loopplus;

        vVariablesChanged.clear();
        // find the fields where the form has an altered value from the original data
        AddIfChanged( SchematicNameTextField.getText(), mySchematic.getSchematic(),                         "SchematicName" );
        AddIfChanged( SkillGroupAsNum.getText(),        mySchematic.getSkillID(),                           "skillID" );
        AddIfChanged( ComplexityTextField.getText(),    mySchematic.getComplexity(),                        "Complexity" );
        AddIfChanged( DatasizeTextField.getText(),      mySchematic.getDatasize(),                          "Datasize" );
        AddIfChanged( XPTypeAsNum.getText(),            mySchematic.getXPType(),                            "XPType" );
        AddIfChanged( maybeAsNum.getText(),             Integer.valueOf(mySchematic.getMaybe()).toString(), "Maybe" );
        AddIfChanged( IFFSchematicTextField.getText(),  mySchematic.getIFFfilename(),                       "iff_name" );
        AddIfChanged( IFFCreatedTextField.getText(),    mySchematic.getIFFCreatedItem(),                    "created_item_iff" );
        AddIfChanged( XPTextField.getText(),            mySchematic.getXPPoints(),                          "XP" );

        for( loop=0; loop<IngredientRows && loop<iResListUsed; loop++ ) {
            loopplus = loop + 1;
            AddIfChanged( IngredientsTable.getValueAt(loop,0).toString(), mySchematic.getSTFfilename(loop), "part" + loopplus + "STFfilename" );
            AddIfChanged( IngredientsTable.getValueAt(loop,1).toString(), mySchematic.getSTFkey(loop),      "part" + loopplus + "STFkey" );
            AddIfChanged( IngredientsTable.getValueAt(loop,2).toString(), mySchematic.getSTFvalue(loop),    "part" + loopplus + "STFvalue" );
            AddIfChanged( IngredientsTable.getValueAt(loop,3).toString(), mySchematic.getNeeded(loop),      "part" + loopplus + "needed" );
            AddIfChanged( IngredientsTable.getValueAt(loop,4).toString(), mySchematic.getResComp(loop),     "part" + loopplus + "rescomp" );
            AddIfChanged( IngredientsTable.getValueAt(loop,5).toString(), mySchematic.getIdentical(loop),   "part" + loopplus + "identical" );
            AddIfChanged( IngredientsTable.getValueAt(loop,6).toString(), mySchematic.getQuantity(loop),    "part" + loopplus + "quantity" );
            AddIfChanged( IngredientsTable.getValueAt(loop,7).toString(), mySchematic.getOptional(loop),    "part" + loopplus + "optional" );
            AddIfChanged( IngredientsTable.getValueAt(loop,8).toString(), mySchematic.getSTFneeded(loop),   "part" + loopplus + "STFneeded" );
        }

        for( loop=0; loop<ExperimentationRows && loop<iExpListUsed; loop++ ) {
            loopplus = loop + 1;
            AddIfChanged( ExperimentationTable.getValueAt(loop,0).toString(), mySchematic.getExpMain(loop),                 "e" + loopplus + "desc1" );
            AddIfChanged( ExperimentationTable.getValueAt(loop,1).toString(), mySchematic.getExpDesc(loop),                 "e" + loopplus + "desc2" );
            AddIfChanged( ExperimentationTable.getValueAt(loop,2).toString(), Integer.toString(mySchematic.getExpER(loop)), "e" + loopplus + "er" );
            AddIfChanged( ExperimentationTable.getValueAt(loop,3).toString(), Integer.toString(mySchematic.getExpCR(loop)), "e" + loopplus + "cr" );
            AddIfChanged( ExperimentationTable.getValueAt(loop,4).toString(), Integer.toString(mySchematic.getExpCD(loop)), "e" + loopplus + "cd" );
            AddIfChanged( ExperimentationTable.getValueAt(loop,5).toString(), Integer.toString(mySchematic.getExpDR(loop)), "e" + loopplus + "dr" );
            AddIfChanged( ExperimentationTable.getValueAt(loop,6).toString(), Integer.toString(mySchematic.getExpFL(loop)), "e" + loopplus + "fl" );
            AddIfChanged( ExperimentationTable.getValueAt(loop,7).toString(), Integer.toString(mySchematic.getExpHR(loop)), "e" + loopplus + "hr" );
            AddIfChanged( ExperimentationTable.getValueAt(loop,8).toString(), Integer.toString(mySchematic.getExpMA(loop)), "e" + loopplus + "ma" );
            AddIfChanged( ExperimentationTable.getValueAt(loop,9).toString(), Integer.toString(mySchematic.getExpPE(loop)), "e" + loopplus + "pe" );
            AddIfChanged( ExperimentationTable.getValueAt(loop,10).toString(),Integer.toString(mySchematic.getExpOQ(loop)), "e" + loopplus + "oq" );
            AddIfChanged( ExperimentationTable.getValueAt(loop,11).toString(),Integer.toString(mySchematic.getExpSR(loop)), "e" + loopplus + "sr" );
            AddIfChanged( ExperimentationTable.getValueAt(loop,12).toString(),Integer.toString(mySchematic.getExpUT(loop)), "e" + loopplus + "ut" );
            AddIfChanged( ExperimentationTable.getValueAt(loop,13).toString(),Integer.toString(mySchematic.getSlot(loop)),  "e" + loopplus + "slot" );
        }

        // construct SQL query to update
        String SQLquery = "UPDATE " + sDataTable + " SET ";

        // loop through vVariablesChanged
        for( int vloop=0; vloop<vVariablesChanged.size(); vloop++ ) {
            if( vloop != 0 ) {
                SQLquery = SQLquery.concat( "," );
            }
            SQLquery = SQLquery.concat( vVariablesChanged.elementAt(vloop).toString() );
        }
        
        SQLquery = SQLquery.concat( " WHERE schematicID='" );
        SQLquery = SQLquery.concat( Integer.toString(mySchematic.getSchematicID()) );
        SQLquery = SQLquery.concat( "'" );

        // pop-up box with list of changes to be made OK/Cancel
        // if OK execute query
        if( showSQLOkCancelBox() == SQLCheckBox.RET_OK ) {  // this warning is OK
            ExecuteQuery( SQLquery );
        }
    }//GEN-LAST:event_ClickCommitButton

    private void clickRestoreButton(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clickRestoreButton
        clearForm();
        populateForm();
    }//GEN-LAST:event_clickRestoreButton

    private void DClickDraftSchematicsList(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DClickDraftSchematicsList
        if( evt.getClickCount()==2 ) {
            IFFSchematicTextField.setText( DraftSchematicList.getSelectedValue().toString() );
        }
    }//GEN-LAST:event_DClickDraftSchematicsList

    private void XPTypeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_XPTypeFocusGained
        TabbedPane.setSelectedIndex(2);
    }//GEN-LAST:event_XPTypeFocusGained

    private void DClickXPTypeList(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DClickXPTypeList
        if( evt.getClickCount()==2 ) {
            XPTypeTextField.setText( XPTypeList.getSelectedValue().toString() );
            XPTypeAsNum.setText( Integer.toString(XPTypeList.getSelectedIndex()+1) );
        }
    }//GEN-LAST:event_DClickXPTypeList

    private void FocusGainedSkillGroup(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_FocusGainedSkillGroup
        TabbedPane.setSelectedIndex(3);
    }//GEN-LAST:event_FocusGainedSkillGroup

    private void DclickSkillGroupList(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DclickSkillGroupList
        if( evt.getClickCount()==2 ) {
            SkillGroupTextField.setText( SkillGroupList.getSelectedValue().toString() );
            SkillGroupAsNum.setText( Integer.toString(SkillGroupList.getSelectedIndex()+1) );
        }
    }//GEN-LAST:event_DclickSkillGroupList

    private void MaybeLostFocus(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_MaybeLostFocus
        maybeTextField.setText( getMaybeLookupText( Integer.parseInt( maybeAsNum.getText() )));
    }//GEN-LAST:event_MaybeLostFocus

    private void DClickMaybeList(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_DClickMaybeList
        if( evt.getClickCount()==2 ) {
            maybeTextField.setText( MaybeList.getSelectedValue().toString() );
            maybeAsNum.setText( Integer.toString(MaybeListValues[MaybeList.getSelectedIndex()]) );
        }
    }//GEN-LAST:event_DClickMaybeList

    private void MaybeAsNumGainedFocus(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_MaybeAsNumGainedFocus
        TabbedPane.setSelectedIndex(5);
    }//GEN-LAST:event_MaybeAsNumGainedFocus

    private void XPTypeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_XPTypeFocusLost
        XPTypeAsNum.setText( getXPTypeLookupNum( XPTypeTextField.getText() ) );
    }//GEN-LAST:event_XPTypeFocusLost

    private void AddSelectedSchematic(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddSelectedSchematic
        int unusedIndex = UnusedSchematicsList.getSelectedIndex();
        if( unusedIndex > 0 ) {
            AddSchematic( unusedIndex );
            UnusedSchematicsList.clearSelection();
            ReInitialise();                             // alter vectors and lists and stuff
            UnusedTangibleListName.remove(unusedIndex); // alter unused list
        }
    }//GEN-LAST:event_AddSelectedSchematic

    private void AddBlankSchematic(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AddBlankSchematic
        ExecuteQuery( getBlankSchematicString( "New" ) );
        ReInitialise();                                 // alter vectors and lists and stuff
    }//GEN-LAST:event_AddBlankSchematic

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddBlankSchematicButton;
    private javax.swing.JButton AddSchematicButton;
    private javax.swing.JTextField ComplexityTextField;
    private javax.swing.JList CreatedItemList;
    private javax.swing.JTextField DatasizeTextField;
    private javax.swing.JList DraftSchematicList;
    private javax.swing.JTable ExperimentationTable;
    private javax.swing.JTextField IFFCreatedTextField;
    private javax.swing.JTextField IFFSchematicTextField;
    private javax.swing.JTable IngredientsTable;
    private javax.swing.JList MaybeList;
    private javax.swing.JSpinner RecordSpinner;
    private javax.swing.JButton RestoreButton;
    private javax.swing.JTextField SchematicNameTextField;
    private javax.swing.JButton SearchButton;
    private javax.swing.JTextField SkillGroupAsNum;
    private javax.swing.JList SkillGroupList;
    private javax.swing.JTextField SkillGroupTextField;
    private javax.swing.JButton SubmitChangeButton;
    private javax.swing.JTabbedPane TabbedPane;
    private javax.swing.JList UnusedSchematicsList;
    private javax.swing.JScrollPane VariablesTable;
    private javax.swing.JTextField XPTextField;
    private javax.swing.JTextField XPTypeAsNum;
    private javax.swing.JList XPTypeList;
    private javax.swing.JTextField XPTypeTextField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JTextField maybeAsNum;
    private javax.swing.JTextField maybeTextField;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JLabel statusAnimationLabel;
    private javax.swing.JLabel statusMessageLabel;
    private javax.swing.JPanel statusPanel;
    // End of variables declaration//GEN-END:variables

    private final Timer messageTimer;
    private final Timer busyIconTimer;
    private final Icon idleIcon;
    private final Icon[] busyIcons = new Icon[15];
    private int busyIconIndex = 0;

    private JDialog aboutBox;
    private DraftSchematicEditorSQLOkCancelBox SQLCheckBox;



    public void setUpRecordSpinner() {
        SpinnerModel model = null;
        int max = mTest.getNumOfSchematics();
        if( (Integer)(RecordSpinner.getValue()) > max  ) {      //if current value is too high for new range
            model = new SpinnerNumberModel( max, 1, max, 1 );    //then make initial value = max
        }
        else {
            model = new SpinnerNumberModel( 1, 1, max, 1 );
        }
        RecordSpinner.setModel(model);
    }

    private void clearForm() {
        SchematicNameTextField.setText( "" );
        SkillGroupTextField.setText   ( "" );
        ComplexityTextField.setText   ( "" );
        DatasizeTextField.setText     ( "" );
        XPTextField.setText           ( "" );
        XPTypeAsNum.setText           ( "" );
        maybeAsNum.setText            ( "" );
        IFFSchematicTextField.setText ( "" );
        IFFCreatedTextField.setText   ( "" );
        SkillGroupAsNum.setText       ( "" );

        for( int loop=0; loop<IngredientRows; loop++ ) {
            for( int inner=0; inner<IngredientColumns; inner++ ) {
                IngredientsTable.setValueAt( "", loop, inner );
            }
        }

        for( int loop=0; loop<ExperimentationRows; loop++ ) {
            for( int inner=0; inner<ExperimentationColumns; inner++ ) {
                ExperimentationTable.setValueAt( "", loop, inner );
            }
        }

        DraftSchematicList.clearSelection();
        CreatedItemList.clearSelection();
    }

    private void populateForm() {
        mySchematic = mTest.getSchematicByID( (Integer)(RecordSpinner.getValue())-1 );

        //fill a 2D array with the ingredients data
        iResListUsed = mySchematic.getNumberIngredients();
        for( int loop=0; loop<iResListUsed; loop++ ) {
            IngredientArray[loop][0] = mySchematic.getSTFfilename(loop);
            IngredientArray[loop][1] = mySchematic.getSTFkey(loop);
            IngredientArray[loop][2] = mySchematic.getSTFvalue(loop);
            IngredientArray[loop][3] = mySchematic.getNeeded(loop);
            IngredientArray[loop][4] = mySchematic.getResComp(loop);
            IngredientArray[loop][5] = mySchematic.getIdentical(loop);
            IngredientArray[loop][6] = mySchematic.getQuantity(loop);
            IngredientArray[loop][7] = mySchematic.getOptional(loop);
            IngredientArray[loop][8] = mySchematic.getSTFneeded(loop);
        }

        iExpListUsed = mySchematic.getNumberExp();
        for( int loop=0; loop<iExpListUsed; loop++ ) {
            ExperimentationArray[loop][0] = mySchematic.getExpMain(loop);
            ExperimentationArray[loop][1] = mySchematic.getExpDesc(loop);
            ExperimentationArray[loop][2] = String.valueOf(mySchematic.getExpER(loop));
            ExperimentationArray[loop][3] = String.valueOf(mySchematic.getExpCR(loop));
            ExperimentationArray[loop][4] = String.valueOf(mySchematic.getExpCD(loop));
            ExperimentationArray[loop][5] = String.valueOf(mySchematic.getExpDR(loop));
            ExperimentationArray[loop][6] = String.valueOf(mySchematic.getExpFL(loop));
            ExperimentationArray[loop][7] = String.valueOf(mySchematic.getExpHR(loop));
            ExperimentationArray[loop][8] = String.valueOf(mySchematic.getExpMA(loop));
            ExperimentationArray[loop][9] = String.valueOf(mySchematic.getExpPE(loop));
            ExperimentationArray[loop][10]= String.valueOf(mySchematic.getExpOQ(loop));
            ExperimentationArray[loop][11]= String.valueOf(mySchematic.getExpSR(loop));
            ExperimentationArray[loop][12]= String.valueOf(mySchematic.getExpUT(loop));
            ExperimentationArray[loop][13]= String.valueOf(mySchematic.getSlot(loop));
        }

        SchematicNameTextField.setText( mySchematic.getSchematic() );
        SkillGroupAsNum.setText       ( mySchematic.getSkillID() );
        ComplexityTextField.setText   ( mySchematic.getComplexity() );
        DatasizeTextField.setText     ( mySchematic.getDatasize() );
        XPTextField.setText           ( mySchematic.getXPPoints() );
        XPTypeAsNum.setText           ( mySchematic.getXPType() );
        maybeAsNum.setText            ( String.valueOf(mySchematic.getMaybe()) );
        IFFSchematicTextField.setText ( mySchematic.getIFFfilename() );
        IFFCreatedTextField.setText   ( mySchematic.getIFFCreatedItem() );

        maybeTextField.setText        ( getMaybeLookupText(mySchematic.getMaybe()) );
        XPTypeTextField.setText       ( getXPTypeLookupText( Integer.parseInt(mySchematic.getXPType()) ) );
        SkillGroupTextField.setText   ( getSkillGroupLookupText( Integer.parseInt(mySchematic.getSkillID()) ));

        for( int loop=0; loop<iResListUsed; loop++ ) {
            for( int inner=0; inner<IngredientColumns; inner++ ) {
                IngredientsTable.setValueAt( IngredientArray[loop][inner], loop, inner );
            }
        }

        for( int loop=0; loop<iExpListUsed; loop++ ) {
            for( int inner=0; inner<ExperimentationColumns; inner++ ) {
                ExperimentationTable.setValueAt( ExperimentationArray[loop][inner], loop, inner );
            }
        }

        DraftSchematicList.setSelectedValue( IFFSchematicTextField.getText(), true );
       
        CreatedItemList.setSelectedValue( IFFCreatedTextField.getText(), true );

    }

    private void fillMaybeLookupHashTable() {

        MaybeListValues = new int[]{ 0,1,2,3,5,8,9,10,55,99 };
        MaybeListStrings = new String[]{"All complete",
                                        "Ingredients incomplete?",
                                        "Some unused Experimentation",
                                        "Unused Experimentation/Incomplete Ingredients",
                                        "Ingredients done - Experimentation not done",
                                        "Neither Ingredients or Experimentation done",
                                        "Raw schematic - only titles",
                                        "New schematic",
                                        "Pictures",
                                        "PostCU" };

        for( int k=0; k<MaybeListValues.length; k++ )
        {
            MaybeLookup.put( MaybeListValues[k], MaybeListStrings[k] );
        }

    }
    
    private void fillXPTypeLookupHashTable() {  // get this data from table XP
        DatabaseConnection dbconn = new DatabaseConnection();

        String sqlQuery = "SELECT xp_id,xp_name FROM XP";
        ResultSet result = dbconn.Query(sqlQuery);

        try {
            while( result.next() )
            {
                XPTypeLookup.put( result.getInt(1), result.getString(2) );
                vXPTypeList.add( result.getString(2) );
            }
            fillXPTypeTable();
        }
        catch (Exception e) {
            System.out.println("Error loading schematic list." + e.toString());
            e.printStackTrace();
        }
    }

    @Action
    private void fillSkillGroupLookupHashTable() {  // get this data from table XP
        DatabaseConnection dbconn = new DatabaseConnection();

        String sqlQuery = "SELECT skill_id,skill_name FROM skills";
        ResultSet result = dbconn.Query(sqlQuery);
        
        try {
            while( result.next() )
            {
                SkillGroupLookup.put( result.getInt(1), result.getString(2) );
                vSkillGroupList.add( result.getString(2) );
            }
            fillSkillGroupTable();
        }
        catch (Exception e) {
            System.out.println("Error loading skillgroup list." + e.toString());
            e.printStackTrace();
        }
    }
    
    @Action
    private void fillIFFList() {
        DatabaseConnection dbconn = new DatabaseConnection();

        //String sqlQuery = "SELECT sIFFfilename FROM decoded_iff WHERE sIFFfilename LIKE 'object/draft_schematic/%' ORDER BY sIFFfilename";
        String sqlQuery = "SELECT iff_name FROM " + sDataTable + " ORDER BY iff_name";
        ResultSet result = dbconn.Query(sqlQuery);

        try {
            while( result.next() )
            {
                IFFList.add( result.getString(1) );
            }
            DraftSchematicList.setListData(IFFList);
        }
        catch (Exception e) {
            System.out.println("Error loading draft_schematic list." + e.toString());
            e.printStackTrace();
        }
    }

    @Action
    private void fillTangibleList() {
        DatabaseConnection dbconn = new DatabaseConnection();

        String sqlQuery = "SELECT sIFFfilename,sCraftedItemName FROM decoded_iff " +
                "WHERE sIFFFilename like 'object/draft_schematic/%' AND sCraftedItemName <> '' " +
                "ORDER BY sCraftedItemName";
        ResultSet result = dbconn.Query(sqlQuery);
        
        try {
            while( result.next() )
            {
                String s1 = result.getString(1);    //  IFFfilename
                TangibleListIFF.add( s1 );
                if( ! IFFList.contains(s1) ) {
                    UnusedTangibleListIFF.add( s1 );
                    UnusedTangibleListName.add( result.getString(2) );    //  Schematic Name
                }
            }
            CreatedItemList.setListData(TangibleListIFF);
            UnusedSchematicsList.setListData(UnusedTangibleListName);
        }
        catch (Exception e) {
            System.out.println("Error loading tangible list." + e.toString());
            e.printStackTrace();
        }
    }

    private void fillMaybeList() {
        MaybeList.setListData( MaybeListStrings );
    }

    private String getMaybeLookupText( int i ) {
        String s = (String)MaybeLookup.get(i);
        if (s != null) {
            return( s );
        }
        else {
            return "";
        }
    }

    private String getXPTypeLookupText( Integer i ) {
        String s = (String)XPTypeLookup.get(i);
        if (s != null) {
            return( s );
        }
        else {
            return "";
        }
    }

    private String getXPTypeLookupNum( String s ) {
        for( int loop=1; loop<XPTypeLookup.size(); loop++ ) {
            if( s.equalsIgnoreCase( (String)XPTypeLookup.get(loop) ) ) {
                return( Integer.toString(loop) );
            }
        }
        return "0";
    }

    
    private String getSkillGroupLookupText( Integer i ) {
        String s = (String)SkillGroupLookup.get(i);
        if (s != null) {
            return( s );
        }
        else {
            return "";
        }
    }

    private void fillXPTypeTable() {
        XPTypeList.setListData( vXPTypeList );
    }

    private void fillSkillGroupTable() {
        SkillGroupList.setListData( vSkillGroupList );
    }
    
    private void AddIfChanged( String screenField, String schematicField, String addString ) {
        if( screenField.isEmpty() || schematicField.isEmpty() ) {
        }
        else
        {
            if( screenField.compareToIgnoreCase(schematicField) != 0 ) {
                vVariablesChanged.add( addString + "='" + screenField + "'" );
            }
        }
    }

    @Action
    private void ExecuteQuery( String query ) {
        try {
            DatabaseConnection dbconn = new DatabaseConnection();
            dbconn.Query(query);
        }
        catch (Exception e) {
            System.out.println("Error executing query. " + e.toString());
            e.printStackTrace();
        }
//TODO
        // remove this - maybe add a pop-up dialog?
    }

    @Action
    public int showSQLOkCancelBox() {
        if (SQLCheckBox == null) {
            JFrame mainFrame = DraftSchematicEditorApp.getApplication().getMainFrame();
//            SQLCheckBox = new DraftSchematicEditorSQLOkCancelBox(mainFrame);
            SQLCheckBox = new DraftSchematicEditorSQLOkCancelBox(mainFrame,true);
            SQLCheckBox.setLocationRelativeTo(mainFrame);
        }
        DraftSchematicEditorApp.getApplication().show(SQLCheckBox);
        
        return( SQLCheckBox.getReturnStatus() );
    }
    
    private void ReInitialise() {
        mTest = null;
        initSchematics();
        setUpRecordSpinner();
    }

    // although it is obviously possible to insert the schematic in one step it's
    // simpler to use the method already written for adding a blank and then
    // alter the fields we have information for with an update
    private void AddSchematic( int unusedIndex ) {
        DatabaseConnection dbconn = new DatabaseConnection();

        // add a blank schematic - we will rename it in a bit
        ExecuteQuery( getBlankSchematicString( "temp_schematic_dse" ) );

        // now update that schematic
        String sName = UnusedTangibleListName.get(unusedIndex).toString();
        String sIFF = UnusedTangibleListIFF.get(unusedIndex).toString();

        String SQL;

        // derive Ingredient and Experimentation STF info from IFF
        SQL = "SELECT * FROM newsc2 WHERE IFFfilename='" + sIFF + "'";
        ResultSet result = dbconn.Query( SQL );

        try {

            result.next();
            for( int loop=0; loop<newSCfields; loop++ ) {
                newSC[loop] = result.getString(loop+1);
                System.out.println( newSC[loop] );
            }

/*
newsc2
IFFFileName, 
 Slot1Filename, Slot1Identifier, 1
 Slot2Filename, Slot2Identifier, 3
 Slot3Filename, Slot3Identifier, 5
 Slot4Filename, Slot4Identifier, 7
 Slot5Filename, Slot5Identifier, 9
 Slot6Filename, Slot6Identifier, 11
 Slot7Filename, Slot7Identifier, 13
 Slot8Filename, Slot8Identifier, 15
 Slot9Filename, Slot9Identifier, 17
 Slot10Filename, Slot10Identifier, 19
 Slot11Filename, Slot11Identifier, 21
 Slot12Filename, Slot12Identifier, 23
 Slot13Filename, Slot13Identifier, 25
 Slot14Filename, Slot14Identifier, 27
 Slot15Filename, Slot15Identifier, 29
 Exp1Filename, Exp1Identifier, Exp1Identifier2, Exp1Place, 31
 Exp2Filename, Exp2Identifier, Exp2Identifier2, Exp2Place, 35
 Exp3Filename, Exp3Identifier, Exp3Identifier2, Exp3Place, 39
 Exp4Filename, Exp4Identifier, Exp4Identifier2, Exp4Place, 43
 Exp5Filename, Exp5Identifier, Exp5Identifier2, Exp5Place, 47
 Exp6Filename, Exp6Identifier, Exp6Identifier2, Exp6Place, 51
 Exp7Filename, Exp7Identifier, Exp7Identifier2, Exp7Place, 55
 Exp8Filename, Exp8Identifier, Exp8Identifier2, Exp8Place, 59
 Exp9Filename, Exp9Identifier, Exp9Identifier2, Exp9Place, 63
 Exp10Filename, Exp10Identifier, Exp10Identifier2, Exp10Place, 67
 Exp11Filename, Exp11Identifier, Exp11Identifier2, Exp11Place, 71
 Exp12Filename, Exp12Identifier, Exp12Identifier2, Exp12Place, 75
 Exp13Filename, Exp13Identifier, Exp13Identifier2, Exp13Place, 79
 Exp14Filename, Exp14Identifier, Exp14Identifier2, Exp14Place, 83
 Exp15Filename, Exp15Identifier, Exp15Identifier2, Exp15Place, 87
 Exp16Filename, Exp16Identifier, Exp16Identifier2, Exp16Place, 91
 Exp17Filename, Exp17Identifier, Exp17Identifier2, Exp17Place, 95
 Exp18Filename, Exp18Identifier, Exp18Identifier2, Exp18Place, 99
 Exp19Filename, Exp19Identifier, Exp19Identifier2, Exp19Place, 103
 Exp20Filename, Exp20Identifier, Exp20Identifier2, Exp20Place, 107
 Exp21Filename, Exp21Identifier, Exp21Identifier2, Exp21Place, 111
 Exp22Filename, Exp22Identifier, Exp22Identifier2, Exp22Place, 115
 CraftedItemIFF  119

testschematic
SchematicCRC, SchematicID, SchematicName, skillID, XP, XPType, Complexity, Datasize, iff_name, maybe, part1STFfilename, part1STFkey, part1STFvalue, part1needed, part1rescomp, part1identical, part1quantity, part1optional, part1STFneeded, part2STFfilename, part2STFkey, part2STFvalue, part2needed, part2rescomp, part2identical, part2quantity, part2optional, part2STFneeded, part3STFfilename, part3STFkey, part3STFvalue, part3needed, part3rescomp, part3identical, part3quantity, part3optional, part3STFneeded, part4STFfilename, part4STFkey, part4STFvalue, part4needed, part4rescomp, part4identical, part4quantity, part4optional, part4STFneeded, part5STFfilename, part5STFkey, part5STFvalue, part5needed, part5rescomp, part5identical, part5quantity, part5optional, part5STFneeded, part6STFfilename, part6STFkey, part6STFvalue, part6needed, part6rescomp, part6identical, part6quantity, part6optional, part6STFneeded, part7STFfilename, part7STFkey, part7STFvalue, part7needed, part7rescomp, part7identical, part7quantity, part7optional, part7STFneeded, part8STFfilename, part8STFkey, part8STFvalue, part8needed, part8rescomp, part8identical, part8quantity, part8optional, part8STFneeded, part9STFfilename, part9STFkey, part9STFvalue, part9needed, part9rescomp, part9identical, part9quantity, part9optional, part9STFneeded, part10STFfilename, part10STFkey, part10STFvalue, part10needed, part10rescomp, part10identical, part10quantity, part10optional, part10STFneeded, part11STFfilename, part11STFkey, part11STFvalue, part11needed, part11rescomp, part11identical, part11quantity, part11optional, part11STFneeded, e1desc1, e1desc2, e1er, e1cr, e1cd, e1dr, e1fl, e1hr, e1ma, e1pe, e1oq, e1sr, e1ut, e1slot, e2desc1, e2desc2, e2er, e2cr, e2cd, e2dr, e2fl, e2hr, e2ma, e2pe, e2oq, e2sr, e2ut, e2slot, e3desc1, e3desc2, e3er, e3cr, e3cd, e3dr, e3fl, e3hr, e3ma, e3pe, e3oq, e3sr, e3ut, e3slot, e4desc1, e4desc2, e4er, e4cr, e4cd, e4dr, e4fl, e4hr, e4ma, e4pe, e4oq, e4sr, e4ut, e4slot, e5desc1, e5desc2, e5er, e5cr, e5cd, e5dr, e5fl, e5hr, e5ma, e5pe, e5oq, e5sr, e5ut, e5slot, e6desc1, e6desc2, e6er, e6cr, e6cd, e6dr, e6fl, e6hr, e6ma, e6pe, e6oq, e6sr, e6ut, e6slot, e7desc1, e7desc2, e7er, e7cr, e7cd, e7dr, e7fl, e7hr, e7ma, e7pe, e7oq, e7sr, e7ut, e7slot, e8desc1, e8desc2, e8er, e8cr, e8cd, e8dr, e8fl, e8hr, e8ma, e8pe, e8oq, e8sr, e8ut, e8slot, e9desc1, e9desc2, e9er, e9cr, e9cd, e9dr, e9fl, e9hr, e9ma, e9pe, e9oq, e9sr, e9ut, e9slot, e10desc1, e10desc2, e10er, e10cr, e10cd, e10dr, e10fl, e10hr, e10ma, e10pe, e10oq, e10sr, e10ut, e10slot, e11desc1, e11desc2, e11er, e11cr, e11cd, e11dr, e11fl, e11hr, e11ma, e11pe, e11oq, e11sr, e11ut, e11slot, e12desc1, e12desc2, e12er, e12cr, e12cd, e12dr, e12fl, e12hr, e12ma, e12pe, e12oq, e12sr, e12ut, e12slot, e13desc1, e13desc2, e13er, e13cr, e13cd, e13dr, e13fl, e13hr, e13ma, e13pe, e13oq, e13sr, e13ut, e13slot, e14desc1, e14desc2, e14er, e14cr, e14cd, e14dr, e14fl, e14hr, e14ma, e14pe, e14oq, e14sr, e14ut, e14slot, e15desc1, e15desc2, e15er, e15cr, e15cd, e15dr, e15fl, e15hr, e15ma, e15pe, e15oq, e15sr, e15ut, e15slot, created_item_iff
*/

            SQL = "UPDATE " + sDataTable + " SET SchematicName='" + sName + "', " +
                    "iff_name='" + sIFF + "'," +
                    "maybe=9," +
                    "part1STFfilename='" + newSC[1] + "', part1STFkey='" + newSC[2] + "', " +
                    "part2STFfilename='" + newSC[3] + "', part2STFkey='" + newSC[4] + "', " +
                    "part3STFfilename='" + newSC[5] + "', part3STFkey='" + newSC[6] + "', " +
                    "part4STFfilename='" + newSC[7] + "', part4STFkey='" + newSC[8] + "', " +
                    "part5STFfilename='" + newSC[9] + "', part5STFkey='" + newSC[10] + "', " +
                    "part6STFfilename='" + newSC[11] + "', part6STFkey='" + newSC[12] + "', " +
                    "part7STFfilename='" + newSC[13] + "', part7STFkey='" + newSC[14] + "', " +
                    "part8STFfilename='" + newSC[15] + "', part8STFkey='" + newSC[16] + "', " +
                    "part9STFfilename='" + newSC[17] + "', part9STFkey='" + newSC[18] + "', " +
                    "part10STFfilename='" + newSC[19] + "', part10STFkey='" + newSC[20] + "', " +
                    "part11STFfilename='" + newSC[21] + "', part11STFkey='" + newSC[22] + "', " +
// not sure on this next section at all
                    "e1desc1='" + newSC[32] + "', e1desc2='" + newSC[33] + "', e1slot='" + newSC[34] + "', " +
                    "e2desc1='" + newSC[36] + "', e2desc2='" + newSC[37] + "', e2slot='" + newSC[38] + "', " +
                    "e3desc1='" + newSC[40] + "', e3desc2='" + newSC[41] + "', e3slot='" + newSC[42] + "', " +
                    "e4desc1='" + newSC[44] + "', e4desc2='" + newSC[45] + "', e4slot='" + newSC[46] + "', " +
                    "e5desc1='" + newSC[48] + "', e5desc2='" + newSC[49] + "', e5slot='" + newSC[50] + "', " +
                    "e6desc1='" + newSC[52] + "', e6desc2='" + newSC[53] + "', e6slot='" + newSC[54] + "', " +
                    "e7desc1='" + newSC[56] + "', e7desc2='" + newSC[57] + "', e7slot='" + newSC[58] + "', " +
                    "e8desc1='" + newSC[60] + "', e8desc2='" + newSC[61] + "', e8slot='" + newSC[62] + "', " +
                    "e9desc1='" + newSC[64] + "', e9desc2='" + newSC[65] + "', e9slot='" + newSC[66] + "', " +
                    "e10desc1='" + newSC[68] + "', e10desc2='" + newSC[69] + "', e10slot='" + newSC[70] + "', " +
                    "e11desc1='" + newSC[72] + "', e11desc2='" + newSC[73] + "', e11slot='" + newSC[74] + "', " +
                    "e12desc1='" + newSC[76] + "', e12desc2='" + newSC[77] + "', e12slot='" + newSC[78] + "', " +
                    "e13desc1='" + newSC[80] + "', e13desc2='" + newSC[81] + "', e13slot='" + newSC[82] + "'," +
                    "e14desc1='" + newSC[84] + "', e14desc2='" + newSC[85] + "', e14slot='" + newSC[86] + "'," +
                    "e15desc1='" + newSC[88] + "', e15desc2='" + newSC[89] + "', e15slot='" + newSC[90] + "'," +
// above section may not be adequate
                    "created_item_iff='" + newSC[119] + "' WHERE SchematicName='temp_schematic_dse'";
            ExecuteQuery( SQL );

            // need to do STF lookup to get STFValue from STFfilename and STFkey
            int iNew= 0;
            for( int loop=1; loop<22; loop+=2 ) {

                if( newSC[loop].isEmpty() || newSC[loop+1].isEmpty() ) {
                    continue;
                }
                SQL = "SELECT value FROM decoded_stf WHERE stf_filename='" + newSC[loop]  + "' AND keyname='" + newSC[loop+1] + "'";
                try {
                    result = dbconn.Query(SQL);
                    result.next();
                    newSC[iNew] = result.getString(1);
                    iNew++;
                }
                catch (Exception e) {
                    System.out.println("Error executing query. " + e.toString());
                    e.printStackTrace();
                }

            }

            for( int loop=1; loop<=iNew; loop++ ) {
                SQL = "UPDATE " + sDataTable + " SET part" + loop + "STFvalue='" + newSC[loop-1] + "' WHERE SchematicName='" + sName + "' AND iff_name='" + sIFF + "'";
                try {
                    dbconn.Query(SQL);
                }
                catch (Exception e) {
                    System.out.println("Error executing query. " + e.toString());
                    e.printStackTrace();
                }
            }

            // need to replace e?desc1 and e?desc2 with STF lookup equivalent ??


        }
        catch (Exception e) {
            System.out.println("Error loading draft_schematic list." + e.toString());
            e.printStackTrace();
        }

    }


    private String getBlankSchematicString( String sName ) {
        String SQL = "INSERT INTO " + sDataTable + " (SchematicCRC, SchematicID, SchematicName, skillID, XP, XPType, Complexity, Datasize, iff_name, maybe, part1STFfilename, part1STFkey, part1STFvalue, part1needed, part1rescomp, part1identical, part1quantity, part1optional, part1STFneeded, part2STFfilename, part2STFkey, part2STFvalue, part2needed, part2rescomp, part2identical, part2quantity, part2optional, part2STFneeded, part3STFfilename, part3STFkey, part3STFvalue, part3needed, part3rescomp, part3identical, part3quantity, part3optional, part3STFneeded, part4STFfilename, part4STFkey, part4STFvalue, part4needed, part4rescomp, part4identical, part4quantity, part4optional, part4STFneeded, part5STFfilename, part5STFkey, part5STFvalue, part5needed, part5rescomp, part5identical, part5quantity, part5optional, part5STFneeded, part6STFfilename, part6STFkey, part6STFvalue, part6needed, part6rescomp, part6identical, part6quantity, part6optional, part6STFneeded, part7STFfilename, part7STFkey, part7STFvalue, part7needed, part7rescomp, part7identical, part7quantity, part7optional, part7STFneeded, part8STFfilename, part8STFkey, part8STFvalue, part8needed, part8rescomp, part8identical, part8quantity, part8optional, part8STFneeded, part9STFfilename, part9STFkey, part9STFvalue, part9needed, part9rescomp, part9identical, part9quantity, part9optional, part9STFneeded, part10STFfilename, part10STFkey, part10STFvalue, part10needed, part10rescomp, part10identical, part10quantity, part10optional, part10STFneeded, part11STFfilename, part11STFkey, part11STFvalue, part11needed, part11rescomp, part11identical, part11quantity, part11optional, part11STFneeded, e1desc1, e1desc2, e1er, e1cr, e1cd, e1dr, e1fl, e1hr, e1ma, e1pe, e1oq, e1sr, e1ut, e1slot, e2desc1, e2desc2, e2er, e2cr, e2cd, e2dr, e2fl, e2hr, e2ma, e2pe, e2oq, e2sr, e2ut, e2slot, e3desc1, e3desc2, e3er, e3cr, e3cd, e3dr, e3fl, e3hr, e3ma, e3pe, e3oq, e3sr, e3ut, e3slot, e4desc1, e4desc2, e4er, e4cr, e4cd, e4dr, e4fl, e4hr, e4ma, e4pe, e4oq, e4sr, e4ut, e4slot, e5desc1, e5desc2, e5er, e5cr, e5cd, e5dr, e5fl, e5hr, e5ma, e5pe, e5oq, e5sr, e5ut, e5slot, e6desc1, e6desc2, e6er, e6cr, e6cd, e6dr, e6fl, e6hr, e6ma, e6pe, e6oq, e6sr, e6ut, e6slot, e7desc1, e7desc2, e7er, e7cr, e7cd, e7dr, e7fl, e7hr, e7ma, e7pe, e7oq, e7sr, e7ut, e7slot, e8desc1, e8desc2, e8er, e8cr, e8cd, e8dr, e8fl, e8hr, e8ma, e8pe, e8oq, e8sr, e8ut, e8slot, e9desc1, e9desc2, e9er, e9cr, e9cd, e9dr, e9fl, e9hr, e9ma, e9pe, e9oq, e9sr, e9ut, e9slot, e10desc1, e10desc2, e10er, e10cr, e10cd, e10dr, e10fl, e10hr, e10ma, e10pe, e10oq, e10sr, e10ut, e10slot, e11desc1, e11desc2, e11er, e11cr, e11cd, e11dr, e11fl, e11hr, e11ma, e11pe, e11oq, e11sr, e11ut, e11slot, e12desc1, e12desc2, e12er, e12cr, e12cd, e12dr, e12fl, e12hr, e12ma, e12pe, e12oq, e12sr, e12ut, e12slot, e13desc1, e13desc2, e13er, e13cr, e13cd, e13dr, e13fl, e13hr, e13ma, e13pe, e13oq, e13sr, e13ut, e13slot, e14desc1, e14desc2, e14er, e14cr, e14cd, e14dr, e14fl, e14hr, e14ma, e14pe, e14oq, e14sr, e14ut, e14slot, e15desc1, e15desc2, e15er, e15cr, e15cd, e15dr, e15fl, e15hr, e15ma, e15pe, e15oq, e15sr, e15ut, e15slot, created_item_iff) VALUES " +
                "('', 0, '" + sName +"', 0, '0', '0', '0', '0', '', 10, " +
                "'', '', '', '', '', '', '', '', '', " +
                "'', '', '', '', '', '', '', '', '', " +
                "'', '', '', '', '', '', '', '', '', " +
                "'', '', '', '', '', '', '', '', '', " +
                "'', '', '', '', '', '', '', '', '', " +
                "'', '', '', '', '', '', '', '', '', " +
                "'', '', '', '', '', '', '', '', '', " +
                "'', '', '', '', '', '', '', '', '', " +
                "'', '', '', '', '', '', '', '', '', " +
                "'', '', '', '', '', '', '', '', '', " +
                "'', '', '', '', '', '', '', '', '', " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, " +
                "'')";
        return(SQL);
    }

}
